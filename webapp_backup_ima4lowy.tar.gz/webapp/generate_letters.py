#!/usr/bin/env python3
"""Generate standalone PNG placeholders for Arabic letters in multiple sizes.

Default usage (512px output):
    python generate_letters.py --font-path NotoNaskhArabic-Regular.ttf

Generate both 512px and 128px variants:
    python generate_letters.py --font-path NotoNaskhArabic-Regular.ttf --sizes 512 128

The script writes images to assets/images/letters/<size>/filename.png.
"""

import argparse
import os
from typing import Iterable, List, Sequence, Tuple

from PIL import Image, ImageDraw, ImageFont

# Base directory that will contain subfolders for each size
BASE_OUT_DIR = "assets/images/letters"

# Default visual styling
DEFAULT_BG = (14, 165, 150)
DEFAULT_FG = (255, 255, 255)
DEFAULT_FONT_PATH = "NotoNaskhArabic-Regular.ttf"
DEFAULT_FONT_SCALE = 0.7  # font size relative to image dimension

# Map of filename stem -> Arabic character
LETTERS: Sequence[Tuple[str, str]] = [
    ("alef", "أ"),
    ("baa", "ب"),
    ("taa", "ت"),
    ("thaa", "ث"),
    ("jeem", "ج"),
    ("haa", "ح"),
    ("khaa", "خ"),
    ("dal", "د"),
    ("dhal", "ذ"),
    ("raa", "ر"),
    ("zay", "ز"),
    ("seen", "س"),
    ("sheen", "ش"),
    ("sad", "ص"),
    ("dad", "ض"),
    ("ta", "ط"),
    ("zaa", "ظ"),
    ("ain", "ع"),
    ("ghain", "غ"),
    ("fa", "ف"),
    ("qaf", "ق"),
    ("kaf", "ك"),
    ("lam", "ل"),
    ("meem", "م"),
    ("noon", "ن"),
    ("haa2", "ه"),
    ("waw", "و"),
    ("yaa", "ي"),
]


def parse_color(value: str) -> Tuple[int, int, int]:
    """Parse an "R,G,B" string into a color tuple."""
    parts = value.split(",")
    if len(parts) != 3:
        raise ValueError("Color must be provided as R,G,B")
    try:
        r, g, b = (int(part.strip()) for part in parts)
    except ValueError as exc:
        raise ValueError("Color components must be integers between 0 and 255") from exc
    for channel in (r, g, b):
        if not 0 <= channel <= 255:
            raise ValueError("Color components must be between 0 and 255")
    return (r, g, b)


def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def load_font(font_path: str, font_size: int) -> ImageFont.FreeTypeFont:
    try:
        return ImageFont.truetype(font_path, font_size)
    except Exception as exc:  # pylint: disable=broad-except
        print(f"Could not load font at {font_path} -> {exc}")
        print("Falling back to default PIL font (may not render Arabic well).")
        return ImageFont.load_default()


def render_letter(
    letter: str,
    font: ImageFont.ImageFont,
    canvas_size: int,
    bg: Tuple[int, int, int],
    fg: Tuple[int, int, int],
) -> Image.Image:
    img = Image.new("RGB", (canvas_size, canvas_size), bg)
    draw = ImageDraw.Draw(img)
    # Find tight bounding box for the glyph to center precisely
    bbox = draw.textbbox((0, 0), letter, font=font)
    width = bbox[2] - bbox[0]
    height = bbox[3] - bbox[1]
    x = (canvas_size - width) // 2 - bbox[0]
    y = (canvas_size - height) // 2 - bbox[1]
    draw.text((x, y), letter, font=font, fill=fg)
    return img


def generate_letters(
    font_path: str,
    sizes: Iterable[int],
    bg: Tuple[int, int, int],
    fg: Tuple[int, int, int],
    font_scale: float,
) -> None:
    for size in sizes:
        out_dir = os.path.join(BASE_OUT_DIR, str(size))
        ensure_dir(out_dir)
        font_size = max(1, int(size * font_scale))
        font = load_font(font_path, font_size)
        print(f"Generating {len(LETTERS)} letters at {size}x{size}px -> {out_dir}")
        for stem, glyph in LETTERS:
            image = render_letter(glyph, font, size, bg, fg)
            out_path = os.path.join(out_dir, f"{stem}.png")
            image.save(out_path, format="PNG")
            print(f"  • {out_path}")


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate Arabic letter placeholder images.")
    parser.add_argument(
        "--font-path",
        default=DEFAULT_FONT_PATH,
        help="Path to a TTF font that supports Arabic glyphs (default: %(default)s)",
    )
    parser.add_argument(
        "--sizes",
        nargs="+",
        type=int,
        default=[512],
        help="Image sizes (pixels) to generate, e.g. --sizes 512 128",
    )
    parser.add_argument(
        "--bg",
        type=parse_color,
        default=DEFAULT_BG,
        help="Background color as R,G,B (default: 14,165,150)",
    )
    parser.add_argument(
        "--fg",
        type=parse_color,
        default=DEFAULT_FG,
        help="Foreground/text color as R,G,B (default: 255,255,255)",
    )
    parser.add_argument(
        "--font-scale",
        type=float,
        default=DEFAULT_FONT_SCALE,
        help="Font size as a fraction of image size (default: %(default)s)",
    )
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> None:
    args = parse_args(argv)
    generate_letters(
        font_path=args.font_path,
        sizes=args.sizes,
        bg=args.bg,
        fg=args.fg,
        font_scale=args.font_scale,
    )


if __name__ == "__main__":
    main()
