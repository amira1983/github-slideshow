# Andalusian Quest (webapp)

An opinionated Cloudflare Pages project that powers a multilingual Andalusian history & culture quiz together with an Arabic alphabet asset pipeline.  The codebase is ready to serve as both a responsive website and an API layer for mobile clients.

## ✨ Features
- **Multilingual quiz bank** – Arabic, English, and German prompts/options spanning `q01`–`q80` (alphabet, values, Andalusian heritage, and Seerah sets ready to consume).
- **REST API** – `/api/questions`, `/api/questions/:id`, `/api/questions/random`, and `/api/categories` exposed from Hono.
- **Edge-rendered marketing site** – Hero section, onboarding steps, live API preview widget, and data summaries rendered via server-side JSX.
- **Letter asset pipeline** – `generate_letters.py` produces consistent PNG placeholders (512×512 & 128×128) ready for Flutter integration; the repository already includes freshly generated assets using the bundled Noto Naskh Arabic font.
- **Cloudflare-ready tooling** – Vite build, Wrangler Pages deployment scripts, PM2 ecosystem for sandbox dev, and JSON type generation hook.

## 🗂 Directory Layout
```
webapp/
├── assets/
│   ├── data/questions.json        # Quiz bank containing q01–q80
│   └── images/letters/            # Generated PNGs (create with script)
├── public/static/                 # Frontend assets (CSS & JS)
├── src/
│   ├── components/HomePage.tsx    # Landing page layout
│   ├── data/questions.ts          # Typed question helpers & summaries
│   ├── index.tsx                  # Hono routes & API handlers
│   └── renderer.tsx               # Global HTML shell
├── dist/                          # Build output (after `npm run build`)
├── ecosystem.config.cjs           # PM2 launcher for sandbox
├── generate_letters.py            # Letter PNG generator (configurable)
├── package.json
├── tsconfig.json
└── wrangler.jsonc
```

## 🚀 Quick Start
```bash
npm install
npm run dev          # Vite dev server (fast refresh)

# Cloudflare Pages simulator (port 3000)
npm run clean-port
npm run build        # required before the first dev:sandbox run
pm2 start ecosystem.config.cjs
curl http://localhost:3000   # optional health check
```

### Production Build & Deploy
```bash
npm run build
npm run deploy         # Deploy to default project
npm run deploy:prod    # Deploy using project name "webapp"
```

> **Wrangler auth**: run `npx wrangler whoami` after `setup_cloudflare_api_key` (per instructions) to confirm credentials before deploying.

### Type Hints for Bindings
Generate interfaces grounded in your Wrangler configuration when needed:
```bash
npm run cf-typegen
```
Then instantiate Hono with typed bindings (optional):
```ts
const app = new Hono<{ Bindings: CloudflareBindings }>({})
```

## 📊 API Overview
| Method | Endpoint | Description |
| ------ | -------- | ----------- |
| GET | `/api/questions` | Returns the full quiz bank (`items: Question[]`). |
| GET | `/api/questions/:id` | Fetch a single question by identifier (404 if missing). |
| GET | `/api/questions/random` | Picks a random quiz item for practice drills. |
| GET | `/api/categories` | Aggregated counts per category. |

Sample response payloads are visible on the landing page “Fetch preview question” widget.

## 🧠 Quiz Data Structure
```ts
type Question = {
  id: string
  category: string
  promptAr: string
  promptEn: string
  promptDe: string
  optionsAr: string[]
  optionsEn: string[]
  optionsDe: string[]
  correctIndex: number
  source: string
}
```
- Extend `assets/data/questions.json` with additional items (`q81` onward, seasonal packs, etc.) and they are automatically bundled.
- For offline mobile usage, bundle the JSON directly; otherwise consume the API routes above.

## 🔡 Letter Asset Pipeline
Generate the 28 Arabic letter placeholders in any size:
```bash
pip install pillow
python generate_letters.py --font-path assets/fonts/NotoNaskhArabic-Regular.ttf --sizes 512 128
```
- Outputs to `assets/images/letters/<size>/<slug>.png` (512×512 and 128×128 variants already committed).
- Override colors and font scale:
  ```bash
  python generate_letters.py --font-path Amiri-Regular.ttf --sizes 128 \
    --bg 30,64,175 --fg 255,255,255 --font-scale 0.68
  ```
- Flutter integration (pubspec.yaml):
  ```yaml
  assets:
    - assets/images/letters/512/
    - assets/images/letters/128/
  ```

## 🛠 Useful Scripts
| Command | Purpose |
| ------- | ------- |
| `npm run dev` | Local Vite development server. |
| `npm run dev:sandbox` | Run Wrangler Pages dev on port 3000 (via PM2). |
| `npm run clean-port` | Ensure port 3000 is freed before starting dev server. |
| `npm run build` | Generate production-ready worker bundle in `dist/`. |
| `npm run deploy` | Deploy latest build to Cloudflare Pages (default project). |
| `npm run deploy:prod` | Deploy specifying project name `webapp`. |
| `npm run test` | Basic health probe (expects running dev server). |
| `npm run cf-typegen` | Sync TypeScript bindings with Wrangler config. |

## 🌐 Deployment Notes
- **Platform**: Cloudflare Pages (Worker-mode output via Vite/Hono).
- **Static assets**: Served through `/static/*` (CSS + JS already emitted in build output).
- **PM2 workflow**: Use `pm2 start ecosystem.config.cjs` for persistent sandbox servers; inspect with `pm2 logs webapp --nostream`.
- **Compatibility date**: `2024-01-01` (see `wrangler.jsonc`).

## ✅ Status
- **Current state**: ✅ **Active** (build passes, SSR site + API fully wired)
- **Last updated**: 2025-10-26

## 📌 Next Steps (optional)
- Grow the quiz catalog beyond `q80` and consider grouping by difficulty levels for adaptive practice.
- Connect a Cloudflare D1 database or KV for dynamic question management if editors require real-time updates.
- Integrate authentication (Clerk/Auth0) if gated quiz authoring is needed.
- Configure CI/CD (e.g., GitHub Actions) to run `npm run build` and automatic deployments.
