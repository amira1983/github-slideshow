import type { JSX } from 'hono/jsx'
import type { Question } from '../data/questions'

type CategorySummary = {
  name: string
  count: number
}

type HomePageProps = {
  questionCount: number
  categories: CategorySummary[]
  sampleQuestion: Question
}

type SectionProps = {
  title: string
  children: JSX.Element | JSX.Element[] | string
  id?: string
}

const Section = ({ title, children, id }: SectionProps) => (
  <section class="section" id={id}>
    <h2>{title}</h2>
    <div class="section-body">{children}</div>
  </section>
)

export const HomePage = ({ questionCount, categories, sampleQuestion }: HomePageProps) => {
  return (
    <main>
      <header class="hero">
        <div class="hero-inner">
          <p class="eyebrow">Quiz &amp; Literacy Toolkit</p>
          <h1>Andalusian Quest</h1>
          <p class="lead">
            A bilingual learning experience featuring curated quizzes, Arabic alphabet resources, and a responsive
            Cloudflare Pages deployment ready for web and mobile apps.
          </p>
          <div class="cta-group">
            <a class="btn primary" href="#getting-started">
              Explore the App
            </a>
            <a class="btn secondary" href="#api">
              View API Endpoints
            </a>
          </div>
        </div>
        <div class="hero-stats">
          <div class="stat">
            <span class="value">{questionCount}</span>
            <span class="label">Quiz Items</span>
          </div>
          <div class="stat">
            <span class="value">3</span>
            <span class="label">Languages</span>
          </div>
          <div class="stat">
            <span class="value">28</span>
            <span class="label">Letter Assets</span>
          </div>
        </div>
      </header>

      <Section title="Getting Started" id="getting-started">
        <ol class="steps">
          <li>
            <strong>Install dependencies</strong>
            <code>npm install</code>
          </li>
          <li>
            <strong>Generate letter images</strong>
            <code>pip install pillow</code>
            <code>python generate_letters.py --font-path NotoNaskhArabic-Regular.ttf --sizes 512 128</code>
          </li>
          <li>
            <strong>Run locally</strong>
            <code>npm run dev</code>
            <span>Use <code>npm run dev:sandbox</code> for the Cloudflare Pages simulator.</span>
          </li>
          <li>
            <strong>Build &amp; deploy</strong>
            <code>npm run deploy:prod</code>
          </li>
        </ol>
      </Section>

      <Section title="Category Coverage">
        <div class="grid categories">
          {categories.map((category) => (
            <article class="card" key={category.name}>
              <h3>{category.name}</h3>
              <p>
                <strong>{category.count}</strong> question(s)
              </p>
            </article>
          ))}
        </div>
      </Section>

      <Section title="Sample Question">
        <article class="card sample" lang="ar">
          <header>
            <span class="pill">{sampleQuestion.category}</span>
            <h3>{sampleQuestion.promptAr}</h3>
          </header>
          <div class="options">
            {sampleQuestion.optionsAr.map((option, index) => (
              <p class={index === sampleQuestion.correctIndex ? 'correct' : ''} key={option}>
                {option}
              </p>
            ))}
          </div>
          <footer>
            <p lang="en">
              English prompt: <strong>{sampleQuestion.promptEn}</strong>
            </p>
            <p lang="de">
              Deutsch: <strong>{sampleQuestion.promptDe}</strong>
            </p>
            <small>Source: {sampleQuestion.source}</small>
          </footer>
        </article>
      </Section>

      <Section title="REST API" id="api">
        <div class="grid api">
          <article class="card">
            <h3>GET /api/questions</h3>
            <p>Returns the full quiz bank with multilingual prompts.</p>
          </article>
          <article class="card">
            <h3>GET /api/questions/random</h3>
            <p>Provides a random question for quick drills.</p>
          </article>
          <article class="card">
            <h3>GET /api/questions/:id</h3>
            <p>Fetches a single question by its identifier (e.g., <code>q42</code>).</p>
          </article>
        </div>
        <p class="note">
          Tip: configure your mobile app to consume these endpoints or bundle <code>assets/data/questions.json</code>
          for offline support.
        </p>
      </Section>

      <Section title="Letter Asset Pipeline" id="letters">
        <div class="grid letters">
          <article class="card">
            <h3>Scriptable</h3>
            <p>Use <code>generate_letters.py</code> to regenerate consistent PNGs whenever your brand changes.</p>
          </article>
          <article class="card">
            <h3>Multiple Sizes</h3>
            <p>Generate 512×512 hero images and lightweight 128×128 thumbnails in a single command.</p>
          </article>
          <article class="card">
            <h3>Flutter Ready</h3>
            <p>Add the directories to <code>pubspec.yaml</code> and the assets appear instantly in your app.</p>
          </article>
        </div>
      </Section>

      <Section title="Live Preview">
        <article class="card preview">
          <div class="preview-body">
            <p>Click to fetch a fresh random quiz item from the API.</p>
            <button id="preview-btn" type="button" class="btn primary">
              Fetch preview question
            </button>
            <pre id="preview-output" aria-live="polite"></pre>
          </div>
        </article>
      </Section>

      <footer class="footer">
        <p>
          Built with <a href="https://hono.dev" target="_blank" rel="noreferrer">Hono</a> · Deployed on{' '}
          <a href="https://pages.cloudflare.com/" target="_blank" rel="noreferrer">
            Cloudflare Pages
          </a>{' '}
          · Repository ready for CI/CD
        </p>
      </footer>

      <script src="/static/app.js" type="module"></script>
    </main>
  )
}
