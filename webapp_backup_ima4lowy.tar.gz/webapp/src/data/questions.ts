import rawQuestions from '../../assets/data/questions.json'

export type Question = {
  id: string
  category: string
  promptAr: string
  promptEn: string
  promptDe: string
  optionsAr: string[]
  optionsEn: string[]
  optionsDe: string[]
  correctIndex: number
  source: string
}

const questions = rawQuestions as Question[]

export const questionCount = questions.length

export const categorySummaries = Array.from(
  questions.reduce((map, question) => {
    const count = map.get(question.category) ?? 0
    map.set(question.category, count + 1)
    return map
  }, new Map<string, number>())
).map(([name, count]) => ({ name, count }))

export const findQuestion = (id: string) => questions.find((q) => q.id === id)

export const getRandomQuestion = () => {
  return questions[Math.floor(Math.random() * questions.length)]
}

export { questions }
