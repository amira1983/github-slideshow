import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { serveStatic } from 'hono/cloudflare-workers'
import { renderer } from './renderer'
import { HomePage } from './components/HomePage'
import {
  categorySummaries,
  findQuestion,
  getRandomQuestion,
  questionCount,
  questions,
} from './data/questions'

const app = new Hono()

app.use('/api/*', cors())
app.use('/static/*', serveStatic({ root: './public' }))
app.use(renderer)

app.get('/api/questions', (c) => c.json({ items: questions }))

app.get('/api/questions/random', (c) => c.json({ item: getRandomQuestion() }))

app.get('/api/categories', (c) => c.json({ items: categorySummaries }))

app.get('/api/questions/:id', (c) => {
  const question = findQuestion(c.req.param('id'))
  if (!question) {
    return c.json({ error: 'Question not found' }, 404)
  }
  return c.json({ item: question })
})

app.get('/', (c) => {
  return c.render(
    <HomePage
      questionCount={questionCount}
      categories={categorySummaries}
      sampleQuestion={getRandomQuestion()}
    />
  )
})

export default app
