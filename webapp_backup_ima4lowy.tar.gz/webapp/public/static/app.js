const button = document.getElementById('preview-btn')
const output = document.getElementById('preview-output')

async function fetchPreview() {
  if (!output) return
  output.textContent = 'Loading…'
  try {
    const response = await fetch('/api/questions/random')
    if (!response.ok) {
      throw new Error(`Request failed with status ${response.status}`)
    }
    const data = await response.json()
    const { item } = data
    if (!item) {
      output.textContent = 'No question returned.'
      return
    }
    output.textContent = JSON.stringify(
      {
        id: item.id,
        promptEn: item.promptEn,
        correctAnswer: item.optionsEn[item.correctIndex],
      },
      null,
      2,
    )
  } catch (error) {
    output.textContent = `Error: ${error}`
  }
}

if (button) {
  button.addEventListener('click', fetchPreview)
}
